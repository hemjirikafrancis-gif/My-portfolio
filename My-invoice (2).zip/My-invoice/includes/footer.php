</main>
<footer class="site-footer"><div class="container"><p>&copy; <?= date('Y') ?> Invoice Manager</p><p>Clear finances. Better business.</p></div></footer>
</body>
</html>
