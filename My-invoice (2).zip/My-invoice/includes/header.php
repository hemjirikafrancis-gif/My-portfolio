<?php
require_once __DIR__ . '/auth.php';
$pageTitle = $pageTitle ?? 'Invoice Manager';
$activePage = $activePage ?? '';
$flash = get_flash();
function nav_link(string $key, string $label, string $href, string $active): string {
    $class = $key === $active ? ' class="active" aria-current="page"' : '';
    return '<a href="' . e($href) . '"' . $class . '>' . e($label) . '</a>';
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Professional invoice and client management">
    <title><?= e($pageTitle) ?> · Invoice Manager</title>
    <link rel="stylesheet" href="/My-invoice/css/style.css">
    <script defer src="/My-invoice/js/script.js"></script>
</head>

<body>
    <?php if (is_logged_in()): ?>
    <header class="site-header">
        <div class="container header-inner">
            <a class="brand" href="<?= e(BASE_URL) ?>/dashboard.php" aria-label="Invoice Manager dashboard"><span
                    class="brand-mark">IM</span><span>Invoice Manager</span></a>
            <button class="nav-toggle" type="button" aria-label="Open navigation"
                aria-expanded="false"><span></span><span></span><span></span></button>
            <nav class="main-nav" aria-label="Main navigation">
                <?= nav_link('dashboard', 'Dashboard', BASE_URL . '/dashboard.php', $activePage) ?>
                <?= nav_link('clients', 'Clients', BASE_URL . '/clients.php', $activePage) ?>
                <?= nav_link('invoices', 'Invoices', BASE_URL . '/invoices/index.php', $activePage) ?>
                <a class="btn btn-small" href="<?= e(BASE_URL) ?>/invoices/create.php">New invoice</a>
                <a class="logout-link" href="<?= e(BASE_URL) ?>/logout.php">Sign out
                    <span><?= e(current_username()) ?></span></a>
            </nav>
        </div>
    </header>
    <?php endif; ?>
    <main class="container main-content<?= is_logged_in() ? '' : ' auth-main' ?>">
        <?php if ($flash): ?><div class="alert alert-<?= e($flash['type']) ?>" role="status"><?= e($flash['message']) ?>
        </div><?php endif; ?>