<?php

if (!defined('CURRENCY')) {
    define('CURRENCY', '$');
}

function start_session_once(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

function flash(string $type, string $message): void
{
    start_session_once();
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function get_flash(): ?array
{
    start_session_once();
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $flash;
}

function csrf_token(): string
{
    start_session_once();
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_verify(): void
{
    start_session_once();
    $sent = $_POST['csrf'] ?? '';
    if (!is_string($sent) || !hash_equals($_SESSION['csrf'] ?? '', $sent)) {
        http_response_code(403);
        exit('Invalid form token. Go back and try again.');
    }
}

function money($amount): string
{
    return CURRENCY . number_format((float)$amount, 2);
}

function invoice_totals(array $items, float $taxRate = 0, float $discount = 0): array
{
    $subtotal = 0.0;
    foreach ($items as $item) {
        $subtotal += (float)$item['qty'] * (float)$item['unit_price'];
    }
    $discount = max($discount, 0);
    $afterDiscount = max($subtotal - $discount, 0);
    $tax = $afterDiscount * (max($taxRate, 0) / 100);
    return ['subtotal' => $subtotal, 'discount' => $discount, 'tax' => $tax, 'total' => $afterDiscount + $tax];
}

function next_invoice_number(PDO $pdo): string
{
    $prefix = 'INV-' . date('Y') . '-';
    $stmt = $pdo->prepare('SELECT invoice_no FROM invoices WHERE invoice_no LIKE ? ORDER BY id DESC LIMIT 1');
    $stmt->execute([$prefix . '%']);
    $last = $stmt->fetchColumn();
    $next = $last ? ((int)substr((string)$last, strlen($prefix)) + 1) : 1;
    return $prefix . str_pad((string)$next, 4, '0', STR_PAD_LEFT);
}

function effective_status(array $invoice): string
{
    if (($invoice['status'] ?? '') === 'sent' && !empty($invoice['due_date']) && strtotime((string)$invoice['due_date']) < strtotime('today')) {
        return 'overdue';
    }
    return (string)($invoice['status'] ?? 'draft');
}

function status_badge(string $status): string
{
    $classes = ['draft' => 'badge-grey', 'sent' => 'badge-blue', 'paid' => 'badge-green', 'overdue' => 'badge-red'];
    $class = $classes[$status] ?? 'badge-grey';
    return '<span class="badge ' . $class . '">' . e(ucfirst($status)) . '</span>';
}
