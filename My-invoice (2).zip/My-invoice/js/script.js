document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.main-nav');
  navToggle?.addEventListener('click', () => {
    const open = nav?.classList.toggle('is-open') ?? false;
    navToggle.setAttribute('aria-expanded', String(open));
  });
  document.querySelectorAll('[data-href]').forEach((row) => {
    const go = () => { window.location.href = row.dataset.href; };
    row.addEventListener('click', go);
    row.addEventListener('keydown', (event) => { if (event.key === 'Enter' || event.key === ' ') go(); });
  });
  document.querySelectorAll('form[data-confirm]').forEach((form) => form.addEventListener('submit', (event) => {
    if (!window.confirm(form.dataset.confirm || 'Are you sure?')) event.preventDefault();
  }));
  const invoiceForm = document.querySelector('[data-invoice-form]');
  if (!invoiceForm) return;
  const tbody = invoiceForm.querySelector('#items-table tbody');
  const currency = document.querySelector('[data-total]')?.textContent.trim().charAt(0) || '$';
  const fmt = (value) => currency + Number(value || 0).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
  const calculate = () => {
    let subtotal = 0;
    tbody.querySelectorAll('tr').forEach((row) => {
      const qty = Number(row.querySelector('[name="qty[]"]')?.value || 0);
      const price = Number(row.querySelector('[name="price[]"]')?.value || 0);
      const amount = qty * price; subtotal += amount;
      const cell = row.querySelector('.line-total'); if (cell) cell.textContent = fmt(amount);
    });
    const discount = Math.max(Number(invoiceForm.querySelector('[name="discount"]')?.value || 0), 0);
    const rate = Math.max(Number(invoiceForm.querySelector('[name="tax_rate"]')?.value || 0), 0);
    const taxable = Math.max(subtotal - discount, 0); const tax = taxable * rate / 100;
    invoiceForm.querySelector('[data-subtotal]').textContent = fmt(subtotal);
    invoiceForm.querySelector('[data-discount]').textContent = '-' + fmt(discount);
    invoiceForm.querySelector('[data-tax]').textContent = fmt(tax);
    invoiceForm.querySelector('[data-total]').textContent = fmt(taxable + tax);
  };
  document.getElementById('add-row')?.addEventListener('click', () => {
    const row = document.createElement('tr');
    row.innerHTML = '<td><input type="text" name="desc[]" required></td><td><input type="number" min="0.01" step="0.01" name="qty[]" value="1" required></td><td><input type="number" min="0" step="0.01" name="price[]" value="0" required></td><td class="line-total">' + fmt(0) + '</td><td><button type="button" class="icon-button remove-row" aria-label="Remove line">×</button></td>';
    tbody.appendChild(row); row.querySelector('input')?.focus(); calculate();
  });
  tbody.addEventListener('click', (event) => {
    const button = event.target.closest('.remove-row'); if (!button) return;
    if (tbody.rows.length === 1) { tbody.querySelectorAll('input').forEach((input) => input.value = input.name === 'qty[]' ? '1' : input.name === 'price[]' ? '0' : ''); }
    else button.closest('tr')?.remove(); calculate();
  });
  invoiceForm.addEventListener('input', calculate); calculate();
});
