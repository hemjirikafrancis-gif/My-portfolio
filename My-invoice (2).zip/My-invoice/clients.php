<?php
require_once __DIR__.'/includes/auth.php'; require_login();
$editId=(int)($_GET['edit']??0); $error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_verify(); $action=$_POST['action']??'save';
 if($action==='delete'){
  $delId=(int)($_POST['id']??0); $s=$pdo->prepare('SELECT COUNT(*) FROM invoices WHERE client_id=?'); $s->execute([$delId]);
  if($s->fetchColumn()>0) flash('error','Cannot delete a client with existing invoices.'); else { $pdo->prepare('DELETE FROM clients WHERE id=?')->execute([$delId]); flash('success','Client deleted.'); }
  redirect(BASE_URL.'/clients.php');
 }
 $id=(int)($_POST['id']??0); $name=trim($_POST['name']??''); $email=trim($_POST['email']??''); $phone=trim($_POST['phone']??''); $address=trim($_POST['address']??'');
 if($name===''){ $error='Client name is required.'; $editId=$id; }
 elseif($email!==''&&!filter_var($email,FILTER_VALIDATE_EMAIL)){ $error='Enter a valid email address.'; $editId=$id; }
 elseif($id){ $pdo->prepare('UPDATE clients SET name=?,email=?,phone=?,address=? WHERE id=?')->execute([$name,$email,$phone,$address,$id]); flash('success','Client updated.'); redirect(BASE_URL.'/clients.php'); }
 else { $pdo->prepare('INSERT INTO clients(name,email,phone,address) VALUES(?,?,?,?)')->execute([$name,$email,$phone,$address]); flash('success','Client added.'); redirect(BASE_URL.'/clients.php'); }
}
$editing=null; if($editId){$s=$pdo->prepare('SELECT * FROM clients WHERE id=?');$s->execute([$editId]);$editing=$s->fetch();}
$clients=$pdo->query('SELECT * FROM clients ORDER BY name')->fetchAll(); $pageTitle='Clients';$activePage='clients';require_once __DIR__.'/includes/header.php';
?>
<div class="page-heading"><div><span class="eyebrow">Relationships</span><h1>Clients</h1><p>Keep customer details organised and ready for billing.</p></div></div>
<div class="split-layout"><section class="panel form-panel"><div class="section-heading"><div><h2><?= $editing?'Edit client':'Add a client' ?></h2><p><?= $editing?'Update the contact details below.':'Create a reusable billing contact.' ?></p></div></div>
<?php if($error):?><div class="alert alert-error"><?=e($error)?></div><?php endif;?>
<form method="post" class="stack-form"><?=csrf_field()?><input type="hidden" name="id" value="<?= (int)($editing['id']??0) ?>"><input type="hidden" name="action" value="save">
<label>Client name<input type="text" name="name" value="<?=e($editing['name']??'')?>" required></label><label>Email<input type="email" name="email" value="<?=e($editing['email']??'')?>"></label><label>Phone<input type="tel" name="phone" value="<?=e($editing['phone']??'')?>"></label><label>Billing address<textarea name="address" rows="3"><?=e($editing['address']??'')?></textarea></label>
<div class="form-actions"><button class="btn" type="submit"><?= $editing?'Save changes':'Add client' ?></button><?php if($editing):?><a class="btn btn-secondary" href="clients.php">Cancel</a><?php endif;?></div></form></section>
<section class="panel"><div class="section-heading"><div><h2>Client directory</h2><p><?=count($clients)?> saved contact<?=count($clients)===1?'':'s'?></p></div></div><div class="table-wrap"><table class="data-table"><thead><tr><th>Name</th><th>Email</th><th>Phone</th><th class="actions-cell">Actions</th></tr></thead><tbody>
<?php foreach($clients as $c):?><tr><td><strong><?=e($c['name'])?></strong></td><td><?=e($c['email']?:'—')?></td><td><?=e($c['phone']?:'—')?></td><td class="actions-cell"><a class="text-link" href="clients.php?edit=<?=(int)$c['id']?>">Edit</a><form method="post" class="inline-form" data-confirm="Delete this client?"><?=csrf_field()?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=(int)$c['id']?>"><button class="text-link danger-link" type="submit">Delete</button></form></td></tr><?php endforeach;?>
<?php if(!$clients):?><tr><td colspan="4" class="empty-state">No clients yet.</td></tr><?php endif;?></tbody></table></div></section></div>
<?php require_once __DIR__.'/includes/footer.php'; ?>
