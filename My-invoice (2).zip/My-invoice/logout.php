<?php
require_once __DIR__ . '/includes/auth.php';
logout();
start_session_once();
flash('success', 'You have been signed out.');
redirect(BASE_URL . '/index.php');
