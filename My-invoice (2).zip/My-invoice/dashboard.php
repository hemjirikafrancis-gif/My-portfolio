<?php
require_once __DIR__ . '/includes/auth.php';
require_login();
$outstanding = $pdo->query("SELECT COALESCE(SUM((ii.qty * ii.unit_price)),0) FROM invoice_items ii JOIN invoices i ON i.id=ii.invoice_id WHERE i.status='sent'")->fetchColumn();
$paidThisMonth = $pdo->query("SELECT COALESCE(SUM((ii.qty * ii.unit_price)),0) FROM invoice_items ii JOIN invoices i ON i.id=ii.invoice_id WHERE i.status='paid' AND MONTH(i.issue_date)=MONTH(CURDATE()) AND YEAR(i.issue_date)=YEAR(CURDATE())")->fetchColumn();
$overdueCount = $pdo->query("SELECT COUNT(*) FROM invoices WHERE status='sent' AND due_date<CURDATE()")->fetchColumn();
$recent = $pdo->query("SELECT i.id,i.invoice_no,i.status,i.due_date,c.name AS client_name,(SELECT COALESCE(SUM(qty*unit_price),0) FROM invoice_items WHERE invoice_id=i.id) AS total FROM invoices i JOIN clients c ON c.id=i.client_id ORDER BY i.id DESC LIMIT 8")->fetchAll();
$pageTitle='Dashboard'; $activePage='dashboard'; require_once __DIR__.'/includes/header.php';
?>
<div class="page-heading"><div><span class="eyebrow">Overview</span><h1>Good to see you, <?= e(current_username()) ?></h1><p>Here is how your business is performing.</p></div><a class="btn" href="<?= e(BASE_URL) ?>/invoices/create.php">Create invoice</a></div>
<section class="stat-cards" aria-label="Financial summary">
<div class="card"><span class="stat-icon blue">↗</span><div><span>Outstanding</span><strong><?= money($outstanding) ?></strong><small>Awaiting payment</small></div></div>
<div class="card"><span class="stat-icon green">✓</span><div><span>Paid this month</span><strong><?= money($paidThisMonth) ?></strong><small>Successfully collected</small></div></div>
<div class="card"><span class="stat-icon red">!</span><div><span>Overdue invoices</span><strong><?= (int)$overdueCount ?></strong><small>Needs your attention</small></div></div>
</section>
<section class="panel"><div class="section-heading"><div><h2>Recent invoices</h2><p>Your latest billing activity</p></div><a href="<?= e(BASE_URL) ?>/invoices/index.php">View all →</a></div>
<div class="table-wrap"><table class="data-table"><thead><tr><th>Invoice</th><th>Client</th><th>Due date</th><th>Total</th><th>Status</th></tr></thead><tbody>
<?php foreach($recent as $inv): ?><tr data-href="<?= e(BASE_URL) ?>/invoices/view.php?id=<?= (int)$inv['id'] ?>" tabindex="0"><td><strong><?= e($inv['invoice_no']) ?></strong></td><td><?= e($inv['client_name']) ?></td><td><?= e(date('M j, Y',strtotime($inv['due_date']))) ?></td><td><?= money($inv['total']) ?></td><td><?= status_badge(effective_status($inv)) ?></td></tr><?php endforeach; ?>
<?php if(!$recent): ?><tr><td colspan="5" class="empty-state">No invoices yet. Create your first invoice to get started.</td></tr><?php endif; ?>
</tbody></table></div></section>
<?php require_once __DIR__.'/includes/footer.php'; ?>
