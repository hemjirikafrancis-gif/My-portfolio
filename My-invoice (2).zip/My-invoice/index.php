<?php
require_once __DIR__ . '/includes/auth.php';
if (is_logged_in()) redirect(BASE_URL . '/dashboard.php');
$pageTitle = 'Sign in';
require_once __DIR__ . '/includes/header.php';
?>
<section class="login-box">
    <div class="login-brand"><span class="brand-mark large">IM</span><p>Invoice Manager</p></div>
    <div><span class="eyebrow">Welcome back</span><h1>Sign in to your workspace</h1><p class="lede">Manage clients, track payments and create polished invoices.</p></div>
    <form method="post" action="login.php" autocomplete="off" class="stack-form">
        <?= csrf_field() ?>
        <label>Username<input type="text" name="username" required autofocus autocomplete="username"></label>
        <label>Password<input type="password" name="password" required autocomplete="current-password"></label>
        <button type="submit" class="btn btn-full">Sign in</button>
    </form>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
