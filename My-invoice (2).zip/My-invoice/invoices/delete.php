<?php
require_once __DIR__.'/../includes/auth.php';require_login();
if($_SERVER['REQUEST_METHOD']!=='POST')redirect(BASE_URL.'/invoices/index.php');
csrf_verify();$id=(int)($_POST['id']??0);$s=$pdo->prepare('SELECT invoice_no FROM invoices WHERE id=?');$s->execute([$id]);$invoiceNo=$s->fetchColumn();
if($invoiceNo){$pdo->prepare('DELETE FROM invoices WHERE id=?')->execute([$id]);flash('success',"Invoice $invoiceNo deleted.");}else flash('error','Invoice not found.');
redirect(BASE_URL.'/invoices/index.php');
