<?php
require_once __DIR__.'/../includes/auth.php'; require_login();
$status=$_GET['status']??'all'; $allowed=['all','draft','sent','paid','overdue']; if(!in_array($status,$allowed,true))$status='all';
$rows=$pdo->query("SELECT i.id,i.invoice_no,i.issue_date,i.due_date,i.status,i.tax_rate,i.discount,c.name AS client_name,(SELECT COALESCE(SUM(qty*unit_price),0) FROM invoice_items WHERE invoice_id=i.id) AS subtotal FROM invoices i JOIN clients c ON c.id=i.client_id ORDER BY i.id DESC")->fetchAll();
$rows=array_values(array_filter($rows,fn($r)=>$status==='all'||effective_status($r)===$status));
$pageTitle='Invoices';$activePage='invoices';require_once __DIR__.'/../includes/header.php';
?>
<div class="page-heading"><div><span class="eyebrow">Billing</span><h1>Invoices</h1><p>Track every invoice from draft to payment.</p></div><a class="btn" href="create.php">Create invoice</a></div>
<nav class="filter-tabs" aria-label="Invoice status"><?php foreach($allowed as $s):?><a class="<?=$status===$s?'active':''?>" href="?status=<?=e($s)?>"><?=ucfirst($s)?></a><?php endforeach;?></nav>
<section class="panel"><div class="table-wrap"><table class="data-table"><thead><tr><th>Invoice</th><th>Client</th><th>Issued</th><th>Due</th><th>Total</th><th>Status</th></tr></thead><tbody>
<?php foreach($rows as $r): $t=invoice_totals([['qty'=>1,'unit_price'=>$r['subtotal']]],(float)$r['tax_rate'],(float)$r['discount']);?><tr data-href="view.php?id=<?=(int)$r['id']?>" tabindex="0"><td><strong><?=e($r['invoice_no'])?></strong></td><td><?=e($r['client_name'])?></td><td><?=e(date('M j, Y',strtotime($r['issue_date'])))?></td><td><?=e(date('M j, Y',strtotime($r['due_date'])))?></td><td><?=money($t['total'])?></td><td><?=status_badge(effective_status($r))?></td></tr><?php endforeach;?>
<?php if(!$rows):?><tr><td colspan="6" class="empty-state">No invoices match this status.</td></tr><?php endif;?></tbody></table></div></section>
<?php require_once __DIR__.'/../includes/footer.php'; ?>
