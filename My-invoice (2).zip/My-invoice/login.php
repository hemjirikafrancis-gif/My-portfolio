<?php
require_once __DIR__ . '/includes/auth.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect(BASE_URL . '/index.php');
csrf_verify();
if (time() < ($_SESSION['locked_until'] ?? 0)) {
    flash('error', 'Too many attempts. Try again in a few minutes.');
} elseif (attempt_login($pdo, $_POST['username'] ?? '', $_POST['password'] ?? '')) {
    unset($_SESSION['attempts'], $_SESSION['locked_until']);
    flash('success', 'Welcome back.');
    redirect(BASE_URL . '/dashboard.php');
} else {
    $_SESSION['attempts'] = ($_SESSION['attempts'] ?? 0) + 1;
    if ($_SESSION['attempts'] >= 5) { $_SESSION['locked_until'] = time() + 300; $_SESSION['attempts'] = 0; }
    flash('error', 'Invalid username or password.');
}
redirect(BASE_URL . '/index.php');
